# ✅ AI Crypto Trading Bot

Готов к деплою на Railway